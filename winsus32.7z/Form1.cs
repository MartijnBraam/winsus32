﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace winsus32
{
    public partial class Form1 : Form
    {
        private TcpClient Client = null;
        private readonly ConcurrentQueue<String> _queue = new ConcurrentQueue<String>();
        private readonly AutoResetEvent _signal = new AutoResetEvent(false);

        public Form1()
        {
            InitializeComponent();
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String host = this.hostfield.Text;
            int port = Int32.Parse(this.portfield.Text);

            TcpClient tc = new TcpClient(host, port);
            var rt = new Thread(this.readerThread);
            rt.Start(tc);

            var wt = new Thread(this.writerThread);
            wt.Start(tc);

            status.Text = "Maybe connected";
        }

        delegate String GetInputDelegate(Control ctrl);
        public static String GetInput(Control ctrl)
        {
            if (ctrl.InvokeRequired)
            {
                var del = new GetInputDelegate(GetInput);
                ctrl.Invoke(del, ctrl);
                return "";
            }
            else
            {
                string temp = ctrl.Text;
                ctrl.Text = "";
                return temp;
            }
        }

        delegate void AppendBufferDelegate(TextBox ctrl, string text);
        public static void AppendBuffer(TextBox ctrl, string text)
        {
            if (ctrl.InvokeRequired)
            {
                var del = new AppendBufferDelegate(AppendBuffer);
                ctrl.Invoke(del, ctrl, text);
            }
            else
            {
                ctrl.AppendText(text);
            }
        }

        private void readerThread(object client)
        {
            try
            {
                this.Client = (TcpClient)client;
                NetworkStream stream = this.Client.GetStream();
                var reader = new StreamReader(stream);
                var line = "";

                while (true)
                {
                    // Read data from server and append to the buffer control
                    int i = reader.Read();
                    char c = Convert.ToChar(i);
                    string part = "";
                    if(c == '\n')
                    {
                        part = "\r\n";
                    }
                    else
                    {
                        part = c.ToString();
                    }
                    AppendBuffer(this.buffer, part);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                this.Client.Close();
            }
        }

        private void writerThread(object client)
        {
            try
            {
                this.Client = (TcpClient)client;
                NetworkStream stream = this.Client.GetStream();
                var writer = new StreamWriter(stream);

                string line;
                while (true)
                {
                    if(_queue.TryDequeue(out line))
                    {
                        writer.Write(line + "\n");
                        writer.Flush();
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                this.Client.Close();
            }
        }

        private void inputfield_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                string text = GetInput(this.inputfield);
                _queue.Enqueue(text);
                AppendBuffer(this.buffer, text+"\r\n");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Client.Close();
        }
    }
}
